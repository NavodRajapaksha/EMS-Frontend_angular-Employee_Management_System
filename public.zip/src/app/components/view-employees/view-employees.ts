import { Component } from '@angular/core';

@Component({
  selector: 'app-view-employees',
  imports: [],
  templateUrl: './view-employees.html',
  styleUrl: './view-employees.css',
})
export class ViewEmployees {

}
